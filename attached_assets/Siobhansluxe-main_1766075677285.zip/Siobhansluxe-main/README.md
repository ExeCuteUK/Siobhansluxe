
  # Premium Cleaning Service App

  This is a code bundle for Premium Cleaning Service App. The original project is available at https://www.figma.com/design/0Sth9gNTMT3ONJv0Bawfxc/Premium-Cleaning-Service-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  