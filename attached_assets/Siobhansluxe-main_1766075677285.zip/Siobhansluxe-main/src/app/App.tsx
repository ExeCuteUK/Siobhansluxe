import { Sparkles, Shirt, Package, Phone, Mail, MapPin, Star } from 'lucide-react';
import { ServiceCard } from './components/ServiceCard';
import { ImageWithFallback } from './components/figma/ImageWithFallback';

export default function App() {
  const services = [
    {
      icon: <Sparkles size={48} />,
      title: "Premium Home Cleaning",
      description: "Transform your home with our professional cleaning service. We use premium products and techniques to ensure every corner sparkles.",
      features: [
        "Deep cleaning of all rooms",
        "Kitchen & bathroom sanitization",
        "Dusting, vacuuming & mopping",
        "Premium professional products",
        "Flexible scheduling"
      ]
    },
    {
      icon: <Shirt size={48} />,
      title: "In-House Ironing & Laundry",
      description: "Professional ironing and laundry service delivered right to your home. Perfect for weekly household needs.",
      features: [
        "Professional pressing & folding",
        "Delicate fabric care",
        "Same-day service available",
        "Pick-up and delivery",
        "Premium detergents"
      ]
    },
    {
      icon: <Package size={48} />,
      title: "Remote Ironing Service",
      description: "Large-scale ironing solutions for businesses and bulk orders. Send us your garments and we'll handle the rest.",
      features: [
        "Bulk order discounts",
        "Commercial laundry services",
        "Quick turnaround times",
        "Quality guaranteed",
        "Convenient collection & delivery"
      ]
    }
  ];

  const areas = [
    "Upminster",
    "Basildon",
    "Benfleet",
    "Rayleigh",
    "Southend",
    "Wickford",
    "Leigh On-Sea",
    "Brentwood"
  ];

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-black/95 backdrop-blur-sm border-b border-primary/20 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <div className="flex items-center gap-2">
              <Sparkles className="text-primary" size={32} />
              <span className="text-2xl tracking-wide">Siobhans Luxe</span>
            </div>
            <div className="hidden md:flex items-center gap-8">
              <a href="#services" className="hover:text-primary transition-colors">Services</a>
              <a href="#areas" className="hover:text-primary transition-colors">Areas</a>
              <a href="#contact" className="hover:text-primary transition-colors">Contact</a>
              <a 
                href="#contact" 
                className="bg-primary text-primary-foreground px-6 py-2 rounded-full hover:bg-primary/90 transition-all"
              >
                Book Now
              </a>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-transparent"></div>
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 bg-primary/10 border border-primary/30 rounded-full px-4 py-2 mb-6">
                <Star className="text-primary" size={20} />
                <span className="text-sm">Premium Cleaning Services in Essex</span>
              </div>
              <h1 className="text-5xl md:text-6xl mb-6 leading-tight">
                Luxury Cleaning
                <span className="block text-primary">At Your Service</span>
              </h1>
              <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
                Professional home cleaning, ironing, and laundry services across Essex. 
                Experience the difference of premium care for your home.
              </p>
              <div className="flex flex-wrap gap-4">
                <a 
                  href="#contact" 
                  className="bg-primary text-primary-foreground px-8 py-4 rounded-full hover:bg-primary/90 transition-all shadow-lg shadow-primary/20"
                >
                  Get a Free Quote
                </a>
                <a 
                  href="#services" 
                  className="border-2 border-primary text-primary px-8 py-4 rounded-full hover:bg-primary hover:text-primary-foreground transition-all"
                >
                  View Services
                </a>
              </div>
            </div>
            <div className="relative">
              <div className="absolute inset-0 bg-primary/20 blur-3xl"></div>
              <ImageWithFallback 
                src="https://images.unsplash.com/photo-1758530273367-fcf1aff76d85?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBob21lJTIwY2xlYW5pbmd8ZW58MXx8fHwxNzY1OTg0MzU2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral" 
                alt="Luxury home cleaning service" 
                className="rounded-2xl shadow-2xl relative z-10 w-full h-auto border-2 border-primary/30"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 px-4 sm:px-6 lg:px-8 bg-secondary/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl mb-4">Our Premium Services</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              From spotless homes to perfectly pressed garments, we deliver excellence in every service
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <ServiceCard key={index} {...service} />
            ))}
          </div>
        </div>
      </section>

      {/* Service Areas Section */}
      <section id="areas" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl md:text-5xl mb-6">Service Areas</h2>
              <p className="text-xl text-muted-foreground mb-8">
                We proudly serve communities across Essex, bringing premium cleaning 
                and laundry services right to your doorstep.
              </p>
              <div className="grid grid-cols-2 gap-4">
                {areas.map((area, index) => (
                  <div 
                    key={index} 
                    className="flex items-center gap-3 bg-card border border-primary/20 rounded-lg p-4 hover:border-primary transition-all"
                  >
                    <MapPin className="text-primary flex-shrink-0" size={24} />
                    <span>{area}</span>
                  </div>
                ))}
              </div>
              <p className="text-muted-foreground mt-6 text-sm">
                Don't see your area? Contact us - we may still be able to help!
              </p>
            </div>
            <div className="relative">
              <div className="absolute inset-0 bg-primary/20 blur-3xl"></div>
              <ImageWithFallback 
                src="https://images.unsplash.com/photo-1566447695072-9f6cc2c84fb6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjbGVhbiUyMGx1eHVyeSUyMGludGVyaW9yfGVufDF8fHx8MTc2NTk4NDM1Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral" 
                alt="Clean luxury interior" 
                className="rounded-2xl shadow-2xl relative z-10 w-full h-auto border-2 border-primary/30"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-secondary/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl mb-4">Why Choose Siobhans Luxe?</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Experience the premium difference
            </p>
          </div>
          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4 border-2 border-primary">
                <Star className="text-primary" size={32} />
              </div>
              <h3 className="mb-2">Quality Guaranteed</h3>
              <p className="text-muted-foreground text-sm">
                100% satisfaction or we'll make it right
              </p>
            </div>
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4 border-2 border-primary">
                <Sparkles className="text-primary" size={32} />
              </div>
              <h3 className="mb-2">Premium Products</h3>
              <p className="text-muted-foreground text-sm">
                Professional-grade supplies
              </p>
            </div>
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4 border-2 border-primary">
                <Shirt className="text-primary" size={32} />
              </div>
              <h3 className="mb-2">Expert Team</h3>
              <p className="text-muted-foreground text-sm">
                Trained and vetted professionals
              </p>
            </div>
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4 border-2 border-primary">
                <Phone className="text-primary" size={32} />
              </div>
              <h3 className="mb-2">Flexible Booking</h3>
              <p className="text-muted-foreground text-sm">
                Schedule at your convenience
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-gradient-to-br from-primary/10 to-transparent border-2 border-primary/30 rounded-2xl p-12 text-center">
            <h2 className="text-4xl md:text-5xl mb-4">Ready to Experience Siobhans Luxe?</h2>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Get in touch today for a free quote. We'll customize our services to meet your needs.
            </p>
            <div className="flex flex-col sm:flex-row gap-6 justify-center mb-8">
              <a 
                href="tel:01234567890" 
                className="flex items-center justify-center gap-3 bg-primary text-primary-foreground px-8 py-4 rounded-full hover:bg-primary/90 transition-all"
              >
                <Phone size={20} />
                <span>Call Us Now</span>
              </a>
              <a 
                href="mailto:info@premiumclean.com" 
                className="flex items-center justify-center gap-3 border-2 border-primary text-primary px-8 py-4 rounded-full hover:bg-primary hover:text-primary-foreground transition-all"
              >
                <Mail size={20} />
                <span>Email Us</span>
              </a>
            </div>
            <div className="text-muted-foreground space-y-2">
              <p className="flex items-center justify-center gap-2">
                <Phone size={18} className="text-primary" />
                01234 567 890
              </p>
              <p className="flex items-center justify-center gap-2">
                <Mail size={18} className="text-primary" />
                info@premiumclean.com
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-secondary/50 border-t border-primary/20 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Sparkles className="text-primary" size={28} />
                <span className="text-xl">Siobhans Luxe</span>
              </div>
              <p className="text-muted-foreground text-sm">
                Luxury cleaning and laundry services across Essex.
              </p>
            </div>
            <div>
              <h4 className="mb-4">Services</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#services" className="hover:text-primary transition-colors">Home Cleaning</a></li>
                <li><a href="#services" className="hover:text-primary transition-colors">In-House Ironing</a></li>
                <li><a href="#services" className="hover:text-primary transition-colors">Remote Ironing</a></li>
              </ul>
            </div>
            <div>
              <h4 className="mb-4">Service Areas</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                {areas.map((area, index) => (
                  <li key={index}>{area}</li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="mb-4">Contact</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>01234 567 890</li>
                <li>info@premiumclean.com</li>
                <li>Essex, United Kingdom</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-primary/20 pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2025 Siobhans Luxe. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}